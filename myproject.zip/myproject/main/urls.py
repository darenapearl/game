from django.urls import path
from .views import home, register, login_view ,about_view ,unity_game_view,profile_view ,view_scores,contact_view,download_view,save_score
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path('', home, name='home'),  # Home view
    path('register/', register, name='register'),  # Registration view
    path('login/', login_view, name='login'),  # Login view
    path('about/', about_view, name='about'),
    path('unity_game', unity_game_view, name='unity_game'),
    path('profile/', profile_view, name='profile'),
    path('view_scores/', view_scores, name='view_scores'),
    path('contact/', contact_view, name='contact'),
    path('download/', download_view, name='download'),
    path('save_score/', save_score, name='save_score'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)