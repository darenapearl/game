from django.db import models
from django.contrib.auth.models import User

class PlayerScore(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Link score to the user
    score = models.IntegerField()  # Store the score
    timestamp = models.DateTimeField(auto_now_add=True)  # Automatically set the timestamp when score is added

    def __str__(self):
        return f"{self.user.username}: {self.score} at {self.timestamp}"