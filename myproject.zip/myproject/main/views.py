from django.shortcuts import render
from .models import PlayerScore

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponse
import os  
from django.views.decorators.csrf import csrf_exempt

import json
import logging
from django.http import JsonResponse

from django.contrib.auth.models import User
from .models import PlayerScore

def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('home')  # Redirect to home page after successful registration
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})

from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect

@csrf_exempt
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('profile')  # Redirect to profile page after login
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password.'})
    return render(request, 'login.html') 

def about_view(request):
    return render(request, 'about.html')

    
def unity_game_view(request):
    print("Unity Game View Accessed")
    # Path to the Unity WebGL index.html file
    unity_game_path = os.path.join('main', 'static', 'unity_game', 'index.html')
    try:
        # Open and return the Unity index.html
        with open(unity_game_path, 'r', encoding='utf-8') as file:
            return HttpResponse(file.read(), content_type='text/html')
    except FileNotFoundError:
        # Handle the case where the file is missing
        return HttpResponse("Unity WebGL game file not found.", status=404)

def profile_view(request):
    if not request.user.is_authenticated:
        return redirect('login')  # Redirect back to login if not logged in

    # Fetch the user's scores, ordered by timestamp
    user_scores = PlayerScore.objects.filter(user=request.user).order_by('-timestamp')
    
    # Fetch the leaderboard (top 10 high scores)
    leaderboard = PlayerScore.objects.all().order_by('-score')[:10]
    
    return render(request, 'profile.html', {
        'username': request.user.username,
        'user_scores': user_scores,
        'leaderboard': leaderboard
    })

from django.contrib.auth.decorators import login_required
from .models import PlayerScore

@login_required  # Ensures that only logged-in users can view their scores
def view_scores(request):
    # Retrieve the scores of the logged-in user
    user_scores = PlayerScore.objects.filter(user=request.user).order_by('-timestamp')
    
    return render(request, 'main/view_scores', {
        'user_scores': user_scores
    })    

def contact_view(request):
    return render(request, 'contact.html') 

def download_view(request):
    return render(request, 'download.html')  

 
@csrf_exempt  # Disable CSRF for simplicity (not recommended for production)
def save_score(request):
    if request.method == 'POST':
        try:
            # Load the score data from the request body
            data = json.loads(request.body)
            score = data.get('score')  # Score sent from Unity

            if score is not None:
                if request.user.is_authenticated:  # Check if the user is logged in
                    user = request.user  # Use the logged-in user
                    PlayerScore.objects.create(user=user, score=score)
                    return JsonResponse({'status': 'success', 'message': 'Score saved successfully.'}, status=200)
                else:
                    return JsonResponse({'status': 'error', 'message': 'User not authenticated.'}, status=401)
            else:
                return JsonResponse({'status': 'error', 'message': 'Invalid data.'}, status=400)
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'message': 'Invalid JSON format.'}, status=400)
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)
