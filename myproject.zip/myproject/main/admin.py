from django.contrib import admin
from .models import PlayerScore

admin.site.register(PlayerScore)
# Register your models here.
